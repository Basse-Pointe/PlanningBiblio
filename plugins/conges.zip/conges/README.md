Planning Biblio, Plugin Congés
==============
